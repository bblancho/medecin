$( document ).ready(function() {

    // fetch('http://localhost/medicament/users.json')
    // .then(response => {
    //     if (response.ok) {
    //         response.json()
    //             .then(console.log);
    //     } else {
    //         console.error('server response : ' + response.status);
    //     }
    // });
// alert('hemm') ;
    var city = {
	    "Name": "Marseille",
	    "ZipCode": "13000"
	};
	for (var key in city) {
	    // Au premier tour de boucle, key contiendra "Name", 
	   //et value contiendra "Marseille"
	    var value = city[key];
	    console.log(value + key) ;
	}

	var myImage = document.querySelector('img');

	fetch('http://localhost/medicaments/medicaments_bis.json')
	.then(function(response) {
	  return response.json();
	})
	.then(function(myJson) {
        for (var key in myJson) {
            // Au premier tour de boucle, key contiendra "Name", et value contiendra "Marseille"
            var value = myJson[key];
            console.log(value) ;
            console.log(" id = " + value.id) ;
            console.log(" title = " + value.title) ;
            console.log(" cis_code = " + value.cis_code) ;
            console.log(" iab_improvements = " + value.iab_improvements) ;
            console.log(" generic_groups = " + value.generic_groups) ;
            //console.log(" iab = " + value.iab[0].abstract) ;
            
            // Tableau IAB
                var iab = value.iab ;
                console.log(" Tableau IAB ") ;
                for (var key in iab) {
                    // Au premier tour de boucle, key contiendra "Name", et value contiendra "Marseille"
                    var valueIab = iab[key];
                    console.log(" abstract = " + valueIab.abstract) ;
                    console.log(" advice = " + valueIab.advice) ;
                    console.log(" reason = " + valueIab.reason) ;
                    console.log(" value = " + valueIab.value) ;
                    console.log(" ------ ") ;
                }
                console.log(" Fin du tableau IAB ") ;
            
            
        }
	});

});