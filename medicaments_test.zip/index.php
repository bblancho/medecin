<!DOCTYPE html>
<html lang="fr">
<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

  <!-- Bootstrap Js  -->
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>

  <!-- Mon CSS -->
  <link rel="stylesheet" href="style.css">

  <script type="text/javascript" src="script.js"></script>
</head>

<body class="text-center">
  <main role="main">

    <div class="container">
      <div class="row">
        <div class="col-md-6">
         
          <form method="get" action="">
            <h2 class="h3 mb-3 font-weight-normal"> J’ai déjà un compte </h2>

            <div class="row">
              <label class="label_form_login login_email" for="email" >Identifiant* : </label>
              <input type="email" id="email" name="email" class="form-control" placeholder="Adresse email" required autofocus>
            </div>
                  
            <div class="row">
              <input type="submit" id="search" class="btn btn-primary " name="search" value="Rechercher"> 
            </div>
          </form>
        </div>
      </div><!-- Fin row !-->
    </div><!-- Fin container !-->

   <div class="wrap">
        <div class="search">
          <input type="text" class="searchTerm" placeholder="What are you looking for?">
          <button type="submit" class="searchButton"> <i class="fa fa-search"></i> </button>
        </div>
    </div>

  </main><!-- Fin main !-->
</body>
</html>

